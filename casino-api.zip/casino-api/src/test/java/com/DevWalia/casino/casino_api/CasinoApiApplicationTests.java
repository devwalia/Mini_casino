package com.DevWalia.casino.casino_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CasinoApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
