package com.DevWalia.casino.casino_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CasinoApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(CasinoApiApplication.class, args);
	}

}
